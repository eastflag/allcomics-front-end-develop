export const userProfile = {
    account: 'account',
    profile: 'profile',
    credential: 'credential'
};
