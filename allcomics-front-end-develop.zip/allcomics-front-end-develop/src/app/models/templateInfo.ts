export class TemplateInfo {
    topbar: number;
    botbar: boolean;
    txtTitle: string;
    txtRight: string;

    constructor() {
        this.topbar = 1;
        this.botbar = true;
        this.txtTitle = '';
        this.txtRight = '';
    }
}
