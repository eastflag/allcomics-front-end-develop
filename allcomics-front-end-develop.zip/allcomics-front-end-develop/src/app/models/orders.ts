export class Orders {
    account: string = null;
    type: string = 'order';
    title: string = null;
    episode: string = null;
    isRented: boolean = false;
    createdAt: string = null;
}