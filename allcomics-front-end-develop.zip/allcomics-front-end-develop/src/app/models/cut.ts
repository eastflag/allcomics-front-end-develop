export interface CutModel {
    stereo?: string;
    name?: string;
    error?: string;
    id?: string;
    idx?: number;
    titleId?: string;
    episodeId?: string;
    no?: number;
    image?: string;
}
