export class Showcase {
    id:	string = null;
    titles:	string = null;
}