export class RecentlyViewed {
    titleId: string;
    thumbnail: string;
    name: string;
}
