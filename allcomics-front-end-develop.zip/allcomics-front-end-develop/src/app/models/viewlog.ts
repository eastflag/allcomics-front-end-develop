export class ViewLog {
    id: string = null;
    type: string = 'viewlog';
    createdAt: string = null;
}