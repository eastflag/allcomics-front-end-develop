export class CustomerHistory {
    id: number;
    title: string;
    date: string;
    content: string;
    status: boolean;
    qContent?: string;
    qDate?: string;
}
