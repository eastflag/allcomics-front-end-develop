export class CustomerInquiry {
    q: string;
    a: string;
}
