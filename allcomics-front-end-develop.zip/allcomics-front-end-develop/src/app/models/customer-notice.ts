export class CustomerNotice {
    title: string;
    date: string;
    content: string;
}
